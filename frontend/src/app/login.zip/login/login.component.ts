import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  user: any;

  constructor(private http: HttpClient, private router: Router) {
  }

  ngOnInit() {
    this.user = {
      username: '',
      password: ''
    };
  }

  login() {
    this.http.post('/api/auth/', this.user, {
      'headers': new HttpHeaders({'Content-Type': 'application/json'}),
      'responseType': 'text',
      observe: 'response'
    })
      .subscribe((res: any) => {
        localStorage.setItem('access_token', res.headers.get('Authorization'));
        this.router.navigate(['/actor-list']);
      }, (error) => {
        alert('wrong username or password');
      });
  }
}
